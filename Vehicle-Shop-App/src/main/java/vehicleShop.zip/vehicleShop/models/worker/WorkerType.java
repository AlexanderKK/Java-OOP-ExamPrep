package vehicleShop.models.worker;

public enum WorkerType {

    FirstShift,
    SecondShift

}
