package goldDigger.models.discoverer;

public enum DiscovererKind {

    Anthropologist,
    Archaeologist,
    Geologist,

}
