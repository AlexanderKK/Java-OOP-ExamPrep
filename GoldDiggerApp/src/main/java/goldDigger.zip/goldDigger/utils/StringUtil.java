package goldDigger.utils;

public class StringUtil {

    public static boolean isNullOrEmpty(String input) {
        return input == null || input.trim().isEmpty();
    }

}
