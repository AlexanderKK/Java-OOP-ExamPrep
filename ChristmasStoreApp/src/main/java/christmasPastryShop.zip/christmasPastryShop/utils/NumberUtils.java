package christmasPastryShop.utils;

public class NumberUtils {

    public static boolean isNegativeOrZero(double number) {
        return number <= 0;
    }

}
