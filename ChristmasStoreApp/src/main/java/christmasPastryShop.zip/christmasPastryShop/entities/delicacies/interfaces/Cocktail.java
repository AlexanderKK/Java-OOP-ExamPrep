package christmasPastryShop.entities.delicacies.interfaces;

public interface Cocktail {

    String getName();

    double getPortion();

    double getPrice();

}
