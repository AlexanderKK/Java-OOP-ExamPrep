package robotService.entities.services;

public enum ServiceType {

    MainService,
    SecondaryService

}
