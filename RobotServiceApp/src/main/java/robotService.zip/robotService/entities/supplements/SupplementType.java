package robotService.entities.supplements;

public enum SupplementType {

    MetalArmor,
    PlasticArmor

}
