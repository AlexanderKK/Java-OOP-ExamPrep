package robotService.entities.robot;

public enum RobotType {

    MaleRobot,
    FemaleRobot

}
